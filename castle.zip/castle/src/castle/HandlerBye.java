package castle;

public class HandlerBye extends Handler{
	public HandlerBye(Game game)
	{
		super(game);
	}
	@Override
	public boolean isBye() {
		// TODO Auto-generated method stub
		return true;
	}
	
}
